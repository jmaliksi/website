
public class Vector 
{
	private double[] x;
	
	public Vector(int size)
	{
		x = new double[size];
	}
	
	public void set(int elem, double val)
	{
		x[elem] = val;
	}
	
	public void set(double[] vals)
	{
		for(int i = 0; i < vals.length; i++){
			x[i] = vals[i];
		}
	}
	
	public double get(int elem)
	{
		return x[elem];
	}
	
	public int size()
	{
		return x.length;
	}
	
	public Vector plus(Vector v)
	{
		Vector v2 = new Vector(x.length);
		for(int i = 0; i < x.length; i++){
			v2.set(i, x[i] + v.get(i));
		}
		return v2;
	}
	
	public Vector times(double d)
	{
		Vector v = new Vector(x.length);
		for(int i = 0; i < x.length; i++){
			v.set(i, d * x[i]);
		}
		return v;
	}
	
	public Vector minus(Vector v)
	{
		Vector v2 = new Vector(x.length);
		for(int i = 0; i < x.length; i++){
			v2.set(i, x[i] - v.get(i));
		}
		return v2;
	}
	
	public double dot(Vector v)
	{
		double d = 0;
		for(int i = 0; i < x.length; i++){
			d += x[i] * v.get(i);
		}
		return d;
	}
	
	public String toString()
	{
		String s = "";
		for(int i = 0; i < x.length; i++){
			s += x[i] + ", ";
		}
		return s;
	}
}
