import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;


public class SteepestDescent 
{
	static int iterations;
	
	/**
	 * Calculates Ax = b using an iterative steepest descent algorithm
	 * 
	 * @author Joe Maliksi - jmaliksi3
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException 
	{
		Matrix a = null;
		Vector b = null;
		Vector x0 = null;
		double e = 0;
		int mat = -1;
		
		BufferedReader br = new BufferedReader(new FileReader(new File("input.txt")));
		String line = "";
		while((line = br.readLine()) != null){
			if(line.length() <= 0){
				continue;
			}
			if(line.charAt(0) == 'a'){
				String[] tokens = line.split(" ");
				a = new Matrix(Integer.parseInt(tokens[1]), 
							   Integer.parseInt(tokens[2]));
				mat = 0;
				continue;
			}
			if(mat >= 0 && mat < a.columns()){
				String[] tokens = line.split(" ");
				for(int i = 0; i < tokens.length; i++){
					a.set(mat, i, Double.parseDouble(tokens[i]));
				}
				mat++;
			}
			if(line.charAt(0) == 'b'){
				String[] tokens = line.split(" ");
				b = new Vector(tokens.length-1);
				for(int i = 0; i < tokens.length-1; i++){
					b.set(i, Double.parseDouble(tokens[i+1]));
				}
			}
			if(line.charAt(0) == 'x'){
				String[] tokens = line.split(" ");
				x0 = new Vector(tokens.length-1);
				for(int i = 0; i < tokens.length-1; i++){
					x0.set(i, Double.parseDouble(tokens[i+1]));
				}
			}
			if(line.charAt(0) == 'e'){
				e = Double.parseDouble(line.substring(line.indexOf(" ")));
			}
		}
		br.close();
		
		Vector ans = iterate(a, b, x0, e);
		Vector check = a.apply(ans);
				
		BufferedWriter bw = new BufferedWriter(new FileWriter(new File("output.txt")));
		bw.write("\nIterations: " + iterations);
		bw.newLine();
		bw.write("x~= " + ans);
		bw.newLine();
		bw.write("\nChecking answer: " + check + " ~= " + b);
		bw.close();
	}
	
	public static Vector iterate(Matrix a, Vector b, Vector x0, double epsilon)
	{
		Vector xk = x0;
		Vector dk = dk(a, xk, b);
		double magD = Math.sqrt(dk.dot(dk));
		while(magD >= epsilon){
			xk = descend(a, b, xk);
			dk = dk(a, xk, b);
			magD = Math.sqrt(dk.dot(dk));
			iterations++;
		}
		return xk;
	}

	public static Vector descend(Matrix a, Vector b, Vector x0)
	{
		Vector dk = dk(a, x0, b);
		double distSq = dk.dot(dk);
		double denom = dk.dot(a.apply(dk));
		return x0.plus(dk.times(distSq / denom));
	}
	
	public static Vector dk(Matrix a, Vector xk, Vector b)
	{
		Vector v;
		v = a.apply(xk);
		return v.minus(b).times(-1);
	}
}
