
public class Matrix 
{
	private double[][] a;
	
	public Matrix(int m, int n)
	{
		a = new double[m][n];
	}
	
	public int rows()
	{
		return a.length;
	}
	
	public int columns()
	{
		return a[0].length;
	}
	
	public void set(int m, int n, double val)
	{
		a[m][n] = val;
	}
	
	public void set(double[][] vals)
	{
		for(int i = 0; i < vals.length; i++){
			for(int j = 0; j < vals[i].length; j++){
				a[i][j] = vals[i][j];
			}
		}
	}
	
	public double get(int m, int n)
	{
		return a[m][n];
	}
	
	public Vector apply(Vector v)
	{
		Vector v2 = new Vector(v.size());
		for(int i = 0; i < a.length; i++){
			double d = 0;
			for(int j = 0; j < a[i].length; j++){
				d += a[i][j] * v.get(j);
			}
			v2.set(i, d);
		}
		return v2;
	}
	
	public Matrix transpose()
	{
		Matrix at = new Matrix(this.columns(), this.rows());
		for(int i = 0; i < this.rows(); i++){
			for(int j = 0; j < this.columns(); j++){
				at.set(j, i, a[i][j]);
			}
		}
		return at;
	}
	
	//Based on the JAMA implementation
	public Matrix times(Matrix b)
	{
		Matrix ab = new Matrix(this.rows(), b.columns());
		double bColj[] = new double[b.columns()];
		for(int j = 0; j < b.columns(); j++){
			for(int k = 0; k < b.columns(); k++){
				bColj[k] = b.get(k, j);
			}
			for(int i = 0; i < this.rows(); i++){
				double val = 0;
				for(int k = 0; k < this.columns(); k++){
					val += a[i][k] * bColj[k];
				}
				ab.set(i, j, val);
			}
		}
		return ab;
	}
	
	public String toString()
	{
		String s = "";
		for(int i = 0; i < a.length; i++){
			for(int j = 0; j < a[i].length; j++){
				s += a[i][j] + ", ";
			}
			s += "\n";
		}
		return s;
	}
}
