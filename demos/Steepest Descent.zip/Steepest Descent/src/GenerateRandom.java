
public class GenerateRandom {

	/**
	 * made to generate a 10x10 matrix and a R^10 vector
	 */
	public static void main(String[] args) 
	{
		Matrix a = new Matrix(10, 10);
		for(int i = 0; i < a.rows(); i++){
			for(int j = 0; j < a.columns(); j++){
				a.set(i, j, (int)(Math.random()*10));
			}
		}
		String s = a.toString();
		s = s.replaceAll(".0, ", " ");
		
		System.out.println(s + "\n");
		String s2 = a.times(a.transpose()).toString();
		s2 = s2.replaceAll(".0, ", " ");
		System.out.println(s2);
		
		for(int i = 0; i < 10; i++){
			System.out.print((int)(Math.random()*10) + " ");
		}
		
		
	}
}
