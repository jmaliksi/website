Readme for Project 2: Steepest Descent
by Joseph Maliksi

1) In order to run this file, make sure "input.txt", "output.txt", and "SteepestDescent.jar" 
are all in the same folder.

2) The "interface" is kind of weird. Open up input.txt. The first line should read
"a: <m> <n>" where <m> and <n> are replaced by the corresponding dimensions of the 
matrix you want to create. In the subsequent lines, simply list the row and column data.
Put a space between column entries and carriage return for every new row.

The next thing to write is "b: <elements>" where b is the vector in Ax = b. <elements> 
should be replaced with the contents of vector b, keeping a space between each element.

Specify "x0: <elements>" in the same way that b is defined.

The final variable to set is epsilon, which is written as "e: <error>", replacing <error>
with the decimal error you want to stay within.

Sample: 

a: 2 2
1 0
0 2

b: 3 4

x0: 1 1

e: 0.00001

//end file

Hopefully, illegal lines are ignored, but I (obviously) didn't really focus on the UI. 
I don't think errors will be printed for certain syntax mistakes, so if nothing happens,
check the syntax.

3) Once the input is specified, save input.txt

4) Double click SteepestDescent.jar

5) Open output.txt. It should tell you the number of times the program iterated, the 
approximate solution to Ax=b, and the vector Ax compared with the vector b.