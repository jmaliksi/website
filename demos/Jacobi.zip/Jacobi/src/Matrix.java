
public class Matrix 
{
	private double a[][];
	
	public Matrix(int m, int n)
	{
		this.a = new double[m][n];
	}
	
	public Matrix(double[][] elems)
	{
		//unsafe!
		this.a = elems;
	}
	
	public int rows()
	{
		return a.length;
	}
	
	public int columns()
	{
		return a[0].length;
	}
	
	public void set(int m, int n, double val)
	{
		a[m][n] = val;
	}
	
	public double get(int m, int n)
	{
		return a[m][n];
	}
	
	public Vector apply(Vector v)
	{
		Vector v2 = new Vector(v.size());
		for(int i = 0; i < a.length; i++){
			double d = 0;
			for(int j = 0; j < a[i].length; j++){
				d += a[i][j] * v.get(j);
			}
			v2.set(i, d);
		}
		return v2;
	}
	
	public Matrix transpose()
	{
		Matrix at = new Matrix(this.columns(), this.rows());
		for(int i = 0; i < this.rows(); i++){
			for(int j = 0; j < this.columns(); j++){
				at.set(j, i, a[i][j]);
			}
		}
		return at;
	}
	
	//Based on the JAMA implementation
	public Matrix times(Matrix b)
	{
		Matrix ab = new Matrix(this.rows(), b.columns());
		double bColj[] = new double[b.columns()];
		for(int j = 0; j < b.columns(); j++){
			for(int k = 0; k < b.columns(); k++){
				bColj[k] = b.get(k, j);
			}
			for(int i = 0; i < this.rows(); i++){
				double val = 0;
				for(int k = 0; k < this.columns(); k++){
					val += a[i][k] * bColj[k];
				}
				ab.set(i, j, val);
			}
		}
		return ab;
	}
	
	public String toString()
	{
		String s = "";
		for(int i = 0; i < a.length; i++){
			for(int j = 0; j < a[i].length; j++){
				s += a[i][j] + "\t";
			}
			s += "\n";
		}
		return s;
	}
	
	public static Matrix identity(int m)
	{
		Matrix I = new Matrix(m, m);
		for(int i = 0; i < m; i++){
			for(int j = 0; j < m; j++){
				I.set(i, j, i == j ? 1 : 0);
			}
		}
		return I;
	}
}
