import java.util.ArrayList;


public class Jacobi 
{	
	/* STATIC METHODS */
	public final static double EPSILON = 0.000000001;
	
	public static void main(String[] args)
	{
		Matrix A = Jacobi.generateRandomSymmetric(5);
		Jacobi jacobi = new Jacobi(A);
		System.out.println(A);
		jacobi.unsortedIterate();
		System.out.println(jacobi.getD());
		System.out.println(jacobi.getOffList().size());//iterations
		
		jacobi = new Jacobi(A);
		System.out.println(A);
		jacobi.iterate();
		System.out.println(jacobi.getD());
		System.out.println(jacobi.getOffList().size());//iterations
	}
	
	public static Matrix generateRandomSymmetric(int m)
	{
		Matrix a = new Matrix(m, m);
		
		for(int i = 0; i < a.rows(); i++){
			for(int j = i; j < a.columns(); j++){
				double val = 10 - Math.random() * 20;
				val = (Math.round(val * 1000)) / 1000.0;
				a.set(i, j, val);
				a.set(j, i, val);
			}
		}
		
		return a;
	}
	
	//returns 2 values
	public static double[] quadratic(double a, double b, double c)
	{
		return new double[]{(-b + Math.sqrt(b*b - 4*a*c)) / (2*a),
							(-b - Math.sqrt(b*b - 4*a*c)) / (2*a)};
	}
	
	public static double off(Matrix a)
	{
		double off = 0;
		for(int i = 0; i < a.rows(); i++){
			for(int j = 0; j < a.columns(); j++){
				if(i != j){
					off += a.get(i, j) * a.get(i, j);
				}
			}
		}
		return off;
	}
	
	/* END STATIC METHODS */
	
	/* INSTANCE STUFF */
	private Matrix B, G;
	private ArrayList<Double> offs;
	
	public Jacobi(Matrix a)
	{
		this.offs = new ArrayList<Double>();
		this.B = a;
		this.G = Matrix.identity(a.rows());
		offs.add(off(B));
	}
	
	public Matrix getD()
	{
		return B;
	}
	
	public Matrix getV()
	{
		return G;
	}
	
	public ArrayList<Double> getOffList()
	{
		return offs;
	}
	
	public void iterate()
	{
		while(off(B) > Jacobi.EPSILON){
			step();
		}
	}
	
	public void unsortedIterate()
	{
		while(off(B) > Jacobi.EPSILON){
			for(int i = 0; i < B.rows(); i++){
				for(int j = i+1; j < B.columns(); j++){
					unsortedStep(i, j);
					if(off(B) < Jacobi.EPSILON){
						return;
					}
				}
			}
		}
	}
	
	public void unsortedStep(int i, int j)
	{
		Matrix large = createLarge2x2(B, i, j);
		Matrix[] udut = udutDecomposition(large);
		Matrix g = givens(B, i, j, udut[2]);
		Matrix gtag = g.transpose().times(B).times(g);
		B = gtag;
		G = G.times(g);
		offs.add(off(B));
	}
	
	/**
	 * Does one step of Jacobi's algorithm.
	 */
	public void step()
	{
		int[] kl = findLargest(B);
		Matrix large = createLarge2x2(B, kl[0], kl[1]);
		Matrix[] udut = udutDecomposition(large);
		Matrix g = givens(B, kl[0], kl[1], udut[2]);
		Matrix gtag = g.transpose().times(B).times(g);
		B = gtag;
		G = G.times(g);
		offs.add(off(B));
	}
	
	/**
	 * Finds the largest off diagonal element in Matrix B and returns its position
	 */
	public int[] findLargest(Matrix B)
	{
		int k = 0;
		int l = 1;
		for(int i = 0; i < B.rows(); i++){
			for(int j = i+1; j < B.columns(); j++){ //only search the upper triangle
				if(Math.abs(B.get(i, j)) > Math.abs(B.get(k, l))){
					k = i;
					l = j;
				}
			}
		}
		return new int[]{k, l};
	}
	
	//finds the largest off diagonal element
	//and creates a 2x2 matrix out of it
	public Matrix createLarge2x2(Matrix B, int k, int l)
	{
		Matrix a = new Matrix(2, 2);
		a.set(0, 0, B.get(k, k));
		a.set(0, 1, B.get(k, l));
		a.set(1, 0, B.get(l, k));
		a.set(1, 1, B.get(l, l));
		return a;
	}
	
	/**
	 * Finds the diagonalized decomposition of a 2x2 Matrix
	 * @param a - matrix to decompose
	 * @return - an array with 3 elements: U, A, and U transpose
	 */
	public Matrix[] udutDecomposition(Matrix a)
	{
		Matrix[] udut = new Matrix[3];
		
		//find eigenvalues
		double end = a.get(0, 1) * a.get(1, 0);
		double quadC = a.get(0, 0) * a.get(1, 1);
		double quadB = -a.get(0, 0) - a.get(1, 1);
		double[] eigvals = quadratic(1, quadB, quadC - end);
		
		//create diagonal matrix D
		udut[1] = new Matrix(2, 2);
		udut[1].set(0, 0, eigvals[0]);
		udut[1].set(1, 1, eigvals[1]);
		
		//find eigenvectors
		double xPart = a.get(0, 0) - eigvals[0];
		double yPart = a.get(0, 1);
		Vector u1 = new Vector(2);
		u1.setAll(yPart / xPart, 1);
		u1 = u1.normalized();
		Vector u2 = new Vector(2);
		u2.setAll(-u1.get(1), u1.get(0));
		
		//create U
		udut[0] = new Matrix(2, 2);
		udut[0].set(0, 0, u1.get(0));
		udut[0].set(1, 0, u1.get(1));
		udut[0].set(0, 1, u2.get(0));
		udut[0].set(1, 1, u2.get(1));
		
		//create U transpose
		udut[2] = udut[0].transpose();
		
		return udut;
	}
	
	/**
	 * find the Givens matrix
	 * U is a 2x2 matrix
	 */
	public Matrix givens(Matrix B, int k, int l, Matrix U)
	{
		Matrix givens = Matrix.identity(B.rows());
		givens.set(k, k, U.get(0, 0));
		givens.set(k, l, U.get(0, 1));
		givens.set(l, k, U.get(1, 0));
		givens.set(l, l, U.get(1, 1));
		
		return givens;
	}
	
	/* END INSTANCE STUFF */
}
