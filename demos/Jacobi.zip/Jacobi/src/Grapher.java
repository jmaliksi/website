import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

public class Grapher extends JFrame
{		
	private Matrix A;
	private Jacobi jacobi;
	private Grapher SELF;
	
	public static void main(String args[])
	{
		new Grapher();
	}
	
	public Grapher()
	{		
		SELF = this;
		A = Jacobi.generateRandomSymmetric(5);
		jacobi = new Jacobi(A);
		
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		this.setSize(1000, 750);
		BorderLayout bl = new BorderLayout();
		this.setLayout(bl);
		this.getContentPane().add(new MatrixPrint(), BorderLayout.NORTH);
		this.getContentPane().add(new GraphMaster(), BorderLayout.CENTER);
		this.pack();
		this.setVisible(true);
	}
	
	private class MatrixPrint extends JPanel
	{
		private JTextArea text;
		
		public MatrixPrint()
		{
			this.setPreferredSize(new Dimension(750, 150));
			double off = Jacobi.off(jacobi.getD());
			text = new JTextArea(jacobi.getD().toString() + 
				     			 "\nOff: " + off + 
				     			 "\nIterations: " + jacobi.getOffList().size() +
				     			 "\nln(Off(B)): " + Math.log(off));
			BorderLayout bl = new BorderLayout();
			text.setEditable(false);
			this.setLayout(bl);
			this.add(text, BorderLayout.WEST);
			this.add(new ButtonStuff(), BorderLayout.EAST);
		}
		
		public void updateText()
		{
			double off = Jacobi.off(jacobi.getD());
			text.setText(jacobi.getD().toString() + 
					     "\nOff: " + off + 
					     "\nIterations: " + jacobi.getOffList().size() +
					     "\nln(Off(B)): " + Math.log(off));
		}
		
		private class ButtonStuff extends JPanel
		{
			private ButtonStuff()
			{
				GridLayout gl = new GridLayout(5, 1);
				this.setLayout(gl);
				
				JButton generate = new JButton("Generate");
				generate.addActionListener(
						new ActionListener()
						{
							public void actionPerformed(ActionEvent e) 
							{
								A = Jacobi.generateRandomSymmetric(5);
								jacobi = new Jacobi(A);
								updateText();
								SELF.repaint();
							}
						}
				);
				this.add(generate);
				
				JButton sortedStep = new JButton("Step (sorted)");
				sortedStep.addActionListener(
						new ActionListener()
						{
							public void actionPerformed(ActionEvent e) 
							{
								jacobi.step();
								updateText();
								SELF.repaint();
							}
						}
				);
				this.add(sortedStep);
				
				JButton unsortedStep = new JButton("Step (unsorted)");
				unsortedStep.addActionListener(
						new ActionListener()
						{
							int i = 0, j = 1;
							public void actionPerformed(ActionEvent e) 
							{
								if(i >= jacobi.getD().rows()){
									i = 0;
									j = 1;
								}
								if(j >= jacobi.getD().columns()){
									i++;
									j = i;
								}
								jacobi.unsortedStep(i, j);
								j++;
								updateText();
								SELF.repaint();
							}
						}
				);
				this.add(unsortedStep);
				
				JButton sortedIterate = new JButton("Iterate (sorted)");
				sortedIterate.addActionListener(
						new ActionListener()
						{
							public void actionPerformed(ActionEvent e) 
							{
								jacobi.iterate();
								updateText();
								SELF.repaint();
							}
						}
				);
				this.add(sortedIterate);
				
				JButton unsortedIterate = new JButton("Iterate (unsorted");
				unsortedIterate.addActionListener(
						new ActionListener()
						{
							public void actionPerformed(ActionEvent e) 
							{
								jacobi.unsortedIterate();
								updateText();
								SELF.repaint();
							}
						}
				);
				this.add(unsortedIterate);
			}
		}
	}
	
	private class GraphMaster extends JPanel
	{
		private int originX, originY;
		private int scale;
		
		public GraphMaster()
		{
			scale = 10;
			originX = 25;
			originY = 250;
			
			this.setBackground(Color.white);
			this.setPreferredSize(new Dimension(1000, 600));
			
			this.addMouseMotionListener(
					new MouseMotionAdapter()
					{
						int lastX;
						int lastY;
						
						public void mouseMoved(MouseEvent e)
						{
							lastX = e.getX();
							lastY = e.getY();
						}
						
						public void mouseDragged(MouseEvent e)
						{
							originX += e.getX() - lastX;
							originY += e.getY() - lastY;
							lastX = e.getX();
							lastY = e.getY();
							repaint();
						}
					}
			);
			
			this.addMouseWheelListener(
					new MouseWheelListener()
					{
						public void mouseWheelMoved(MouseWheelEvent e) 
						{
							scale = Math.max(1, scale - e.getWheelRotation());
							repaint();
						}
					}
			);
		}
		
		public void paintComponent(Graphics g)
		{
			g.clearRect(0, 0, this.getWidth(), this.getHeight());
			
			//paint grid
			g.setColor(new Color(225, 225, 225));
			for(int i = originX; i < this.getWidth(); i += scale){
				g.drawLine(i, 0, i, this.getHeight());
			}
			for(int i = originX; i > 0; i -= scale){
				g.drawLine(i, 0, i, this.getHeight());
			}
			for(int i = originY; i < this.getHeight(); i += scale){
				g.drawLine(0, i, this.getWidth(), i);
			}
			for(int i = originY; i > 0; i -= scale){
				g.drawLine(0, i, this.getWidth(), i);
			}
			g.setColor(Color.black);
			g.drawLine(originX, 0, originX, this.getHeight());
			g.drawLine(0, originY, this.getWidth(), originY);
			//end paint grid
			
			//draw theoretical bound
			g.setColor(Color.red);
			for(int x = -originX/scale; x < (this.getWidth()-originX)/scale; x++){
				g.drawLine(translateX(x), translateY(bounds(x)), translateX(x-1), translateY(bounds(x-1)));
			}	
			
			//draw offList
			g.setColor(Color.blue);
			ArrayList<Double> offs = jacobi.getOffList();
			for(int x = 1; x < offs.size(); x++){
				g.drawLine(translateX(x), translateY(Math.log(offs.get(x))), 
						   translateX(x-1), translateY(Math.log(offs.get(x-1))));
			}
		}
		
		private final double bounds(double x)
		{
			return x * Math.log(9.0/10.0) + Math.log(Jacobi.off(A));
		}
		
		//translates a cartesian X to this plane, which has 1 = SCALE
		private int translateX(double x)
		{
			return (int)Math.round((x*scale) + originX);
		}
		
		//see above
		private int translateY(double y)
		{
			return (int)Math.round(originY - (y*scale));
		}
	}
}
