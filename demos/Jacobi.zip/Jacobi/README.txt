To start, simply double click the JAR file.

Buttons:
-Generate - creates a random 5x5 symmetric matrix and resets the graph
-Step (sorted) - Does one step of the Jacobi algorithm
-Step (unsorted) - Does one step of the Jacobi algorithm without choosing the largest value
-Iterate (sorted) - Iterates through the Jacobi algorithm until Off(B) < epsilon
-Iterate (unsorted) - Iterates through the Jacobi algorithm without choosing the largest value until Off(B) < epsilon

Dragging the mouse in the graph allows you to move it around. Scrolling the wheel zooms in or out.