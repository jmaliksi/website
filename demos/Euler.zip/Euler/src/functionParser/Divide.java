package functionParser;

	
final class Divide extends Operation{
	public final void doOp(){
	output.num = leftOperand.num / rightOperand.num;}
}
	
