package functionParser;

final class Multiply extends Operation{
	public final void doOp(){
	output.num = leftOperand.num*rightOperand.num;}
}
