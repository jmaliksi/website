package functionParser;

final class Add extends Operation{
	public final void doOp(){
	output.num = leftOperand.num + rightOperand.num;}
}
	
