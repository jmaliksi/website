import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import functionParser.*;

public class Euler extends JFrame
{
	private FunctionParser parser;
	private Evaluator evalF, evalG;
	private double h, x0, y0, t;
	private GraphMaster gm;
	
	public Euler()
	{
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setSize(500, 500);
		BorderLayout bl = new BorderLayout();
		this.setLayout(bl);
		this.getContentPane().add(gm = new GraphMaster(), BorderLayout.CENTER);
		this.getContentPane().add(new InputTaker(), BorderLayout.EAST);
		this.pack();
		this.setVisible(true);
	}
	
	public void updatePaintStuff()
	{
		gm.originX = (int)Math.round(x0 + 250);
		gm.originY = (int)Math.round(250 - y0);
		this.repaint();
	}
	
	public static void main(String[] args) 
	{
		new Euler();
	}
	
	private class InputTaker extends JPanel
	{
		private JTextField functionF, functionG, step, startPoint, endTime;
		private JButton eval;
		
		public InputTaker()
		{
			this.setPreferredSize(new Dimension(200, 500));
			GridLayout gl = new GridLayout(0, 1);
			this.setLayout(gl);
			this.add(new JLabel("f(x, y):"));
			this.add(functionF = new JTextField(20));
			this.add(new JLabel("g(x, y):"));
			this.add(functionG = new JTextField(20));
			this.add(new JLabel("h="));
			this.add(step = new JTextField(20));
			this.add(new JLabel("x0="));
			this.add(startPoint = new JTextField(20));
			this.add(new JLabel("T="));
			this.add(endTime = new JTextField(20));
			
			parser = new FunctionParser("x, y");
			evalF = new Evaluator(2);
			evalG = new Evaluator(2);
			
			eval = new JButton("Evaluate");
			eval.addActionListener(
					new ActionListener()
					{
						public void actionPerformed(ActionEvent e)
						{
							try{
								parser.parse(functionF.getText(), evalF);
								parser.parse(functionG.getText(), evalG);
							}catch(FunctionParsingException ex){
								System.out.println(ex);
							}
							
							h = Double.parseDouble(step.getText());
							String[] s = startPoint.getText().split(" ");
							x0 = Double.parseDouble(s[0]);
							y0 = Double.parseDouble(s[1]);
							t = Double.parseDouble(endTime.getText());
							updatePaintStuff();
						}
					}
			);
			this.add(eval);
		}
	}
	
	private class GraphMaster extends JPanel
	{
		private int originX, originY;
		private int scale;
		private double xMin, yMin;
		
		public GraphMaster()
		{
			scale = 10;
			originX = 250;
			originY = 250;
			
			this.setBackground(Color.white);
			this.setPreferredSize(new Dimension(500, 500));
			
			this.addMouseMotionListener(
					new MouseMotionAdapter()
					{
						int lastX;
						int lastY;
						
						public void mouseMoved(MouseEvent e)
						{
							lastX = e.getX();
							lastY = e.getY();
						}
						
						public void mouseDragged(MouseEvent e)
						{
							originX += e.getX() - lastX;
							originY += e.getY() - lastY;
							lastX = e.getX();
							lastY = e.getY();
							repaint();
						}
					}
			);
			
			this.addMouseWheelListener(
					new MouseWheelListener()
					{
						public void mouseWheelMoved(MouseWheelEvent e) 
						{
							scale = Math.max(1, scale - e.getWheelRotation());
							repaint();
						}
					}
			);
		}
		
		public void setOriginX(int x)
		{
			originX = x;
		}
		
		public void setOriginY(int y)
		{
			originY = y;
		}
		
		public void paintComponent(Graphics g)
		{
			g.clearRect(0, 0, this.getWidth(), this.getHeight());
			
			//paint grid
			g.setColor(new Color(225, 225, 225));
			for(int i = originX; i < this.getWidth(); i += scale){
				g.drawLine(i, 0, i, this.getHeight());
			}
			for(int i = originX; i > 0; i -= scale){
				g.drawLine(i, 0, i, this.getHeight());
			}
			for(int i = originY; i < this.getHeight(); i += scale){
				g.drawLine(0, i, this.getWidth(), i);
			}
			for(int i = originY; i > 0; i -= scale){
				g.drawLine(0, i, this.getWidth(), i);
			}
			g.setColor(Color.black);
			g.drawLine(originX, 0, originX, this.getHeight());
			g.drawLine(0, originY, this.getWidth(), originY);
			//end paint grid
			
			if(evalF != null && evalG != null){
				graphFunc(g, Color.blue, h);
				graphFunc(g, Color.red, h/10);
				graphFunc(g, Color.green, h/100);
			}
		}
		
		private void graphFunc(Graphics g, Color c, double step)
		{
			g.setColor(c);
			double x, y, xP, yP;
			x = xP = xMin = x0;
			y = yP = yMin = y0;
			
			for(int i = 0; i < t/step; i++){
				x += step * evalF.evaluate(xP, yP);
				if(x < xMin){
					xMin = x;
				}
				y += step * evalG.evaluate(xP, yP);
				if(y < yMin){
					yMin = y;
				}
				g.drawLine(translateX(xP), translateY(yP), translateX(x), translateY(y));
				xP = x;
				yP = y;
			}
		}
		
		//translates a cartesian X to this plane, which has 1 = SCALE
		private int translateX(double x)
		{
			return (int)Math.round((x*scale) + originX);
		}
		
		//see above
		private int translateY(double y)
		{
			return (int)Math.round(originY - (y*scale));
		}
	}
}
