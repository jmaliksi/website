1. Double click Euler.jar
2. Put the f(x, y) equation in the box labeled as such. Do the same for g(x, y)
3. Input the step accuracy under h 
4. Input the starting vector under x0, putting a space between the x and y value
5. Input the ending time T under T
6. Press the Evaluate button

You can use your mouse to navigate the graph by clicking and holding the mouse button 
and dragging it around. Scrolling the mouse wheel will zoom in or out.